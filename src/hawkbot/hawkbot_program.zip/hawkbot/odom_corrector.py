import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from geometry_msgs.msg import TransformStamped
from tf2_ros import TransformBroadcaster
import numpy as np

class OdomCorrector(Node):
    def __init__(self):
        super().__init__('odom_corrector')
        
        # Declare parameters
        self.declare_parameter('robot_ns', '')
        self.robot_ns = self.get_parameter('robot_ns').get_parameter_value().string_value
        
        self.declare_parameter('publish_tf', False)
        self.publish_tf = self.get_parameter('publish_tf').get_parameter_value().bool_value
        
        self.frame_prefix = f"{self.robot_ns}/" if self.robot_ns else ""
        
        # Initialize TF broadcaster if requested
        if self.publish_tf:
            self.tf_broadcaster = TransformBroadcaster(self)
            self.get_logger().info(f"Odom Corrector TF publication ENABLED for: '{self.frame_prefix}odom_combined' -> '{self.frame_prefix}base_footprint'")
        else:
            self.get_logger().info("Odom Corrector TF publication DISABLED.")
        
        # Log status
        self.get_logger().info(f"Odom Corrector initialized for namespace: '{self.robot_ns}'")
        self.get_logger().info(f"Frame prefix will be: '{self.frame_prefix}'")
        
        # Topic subscriptions and publishers
        # Subscribe to raw odom published by HBSDK (usually under namespaced topic e.g. /robot1/odom)
        self.sub = self.create_subscription(
            Odometry,
            'odom',  # will resolve to namespace/odom
            self.odom_callback,
            10
        )
        
        self.pub = self.create_publisher(
            Odometry,
            'odom_corrected',  # will resolve to namespace/odom_corrected
            10
        )

    def odom_callback(self, msg):
        self.get_logger().info("Received odom message, correcting and publishing...", once=True)
        corrected_msg = Odometry()
        corrected_msg.header = msg.header
        
        # 1. Correct the frame IDs to namespaced versions
        corrected_msg.header.frame_id = f"{self.frame_prefix}odom_combined"
        corrected_msg.child_frame_id = f"{self.frame_prefix}base_footprint"
        
        # 2. Copy the pose and twist data
        corrected_msg.pose.pose = msg.pose.pose
        corrected_msg.twist.twist = msg.twist.twist
        
        # 3. Apply a healthy, symmetric positive-definite covariance matrix
        # Pose covariance (6x6 matrix, flat 36 elements)
        # We need realistic values so that EKF can fuse properly.
        # Diagonals: X, Y, Z, Roll, Pitch, Yaw
        pose_cov = np.zeros(36)
        pose_cov[0] = 0.05   # X variance (trust encoders reasonably)
        pose_cov[7] = 0.05   # Y variance
        pose_cov[14] = 1000.0 # Z variance (not measured, planar)
        pose_cov[21] = 1000.0 # Roll variance (planar)
        pose_cov[28] = 1000.0 # Pitch variance (planar)
        # Yaw variance: set to a moderate value so EKF can correct it with IMU
        pose_cov[35] = 0.1    # Yaw variance (10% uncertainty, lets IMU steer)
        
        # Twist covariance (6x6 matrix, flat 36 elements)
        twist_cov = np.zeros(36)
        twist_cov[0] = 0.02   # vx variance
        twist_cov[7] = 1000.0 # vy variance (non-holonomic, cannot slide sideways)
        twist_cov[14] = 1000.0 # vz variance
        twist_cov[21] = 1000.0 # vroll variance
        twist_cov[28] = 1000.0 # vpitch variance
        twist_cov[35] = 0.05   # vyaw variance (moderate trust in encoder rotation speed)
        
        corrected_msg.pose.covariance = list(pose_cov)
        corrected_msg.twist.covariance = list(twist_cov)
        
        # Publish corrected message
        self.pub.publish(corrected_msg)
        
        # Publish TF transform if EKF is disabled/missing
        if self.publish_tf:
            t = TransformStamped()
            t.header = corrected_msg.header
            t.child_frame_id = corrected_msg.child_frame_id
            t.transform.translation.x = corrected_msg.pose.pose.position.x
            t.transform.translation.y = corrected_msg.pose.pose.position.y
            t.transform.translation.z = corrected_msg.pose.pose.position.z
            t.transform.rotation = corrected_msg.pose.pose.orientation
            self.tf_broadcaster.sendTransform(t)

def main(args=None):
    rclpy.init(args=args)
    node = OdomCorrector()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
