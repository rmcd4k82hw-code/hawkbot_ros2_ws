from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import LifecycleNode
from launch_ros.actions import Node
from launch.substitutions import LaunchConfiguration
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument, ExecuteProcess, TimerAction
from launch.actions import LogInfo
import lifecycle_msgs.msg
import os


def generate_launch_description():

    share_dir = get_package_share_directory('ydlidar_ros2_driver')
    params_declare= DeclareLaunchArgument('params_file',
                                           default_value=os.path.join(share_dir, 'params', 'ydlidar.yaml'))



    driver_node =  LaunchDescription([
        DeclareLaunchArgument(
            'delay_seconds',
            default_value='5',
            description=''
        ),
        TimerAction(
            period=LaunchConfiguration('delay_seconds'),
            actions=[
                Node(
                    package='ydlidar_ros2_driver',
                    executable='ydlidar_ros2_driver_node',
                    name='ydlidar_ros2_driver_node',
                    output='screen',
                    emulate_tty=True,
                    parameters=[{'robot_ip': LaunchConfiguration('robot_ip')},
                                os.path.join(share_dir, 'params', 'ydlidar.yaml')],
                    namespace='/',
                )
            ]
        )
    ])

    return LaunchDescription([
        params_declare,
        driver_node,
    ])
